package controladorDao.persona;

import contrladorLista.DynamicList;
import controladorDao.DaoImplement;
import modelo.Compra;

public class CompraControl extends DaoImplement<Compra> {
        private Compra compra;
        private DynamicList<Compra> compras;

        public CompraControl() {
                super(Compra.class);
        }

        public Compra getCompra() {
                if(compra == null) {
                        compra = new Compra();
                }
                return compra;
        }

        public void setCompra(Compra compra) {
                this.compra = compra;
        }

        public DynamicList<Compra> getCompras() {
                compras = all();
                return compras;
        }

        public void setCompras(DynamicList<Compra> compras) {
                this.compras = compras;
        }  
}
