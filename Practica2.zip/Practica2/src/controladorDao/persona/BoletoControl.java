package controladorDao.persona;
;
import contrladorLista.DynamicList;
import controladorDao.DaoImplement;
import modelo.Boleto;

public class BoletoControl extends DaoImplement<Boleto>{
        private Boleto boleto;
        private DynamicList<Boleto> boletos;

        public BoletoControl(Class<Boleto> clazz) {
                super(clazz);
        }

        public Boleto getBoleto() {
                return boleto;
        }

        public void setBoleto(Boleto boleto) {
                this.boleto = boleto;
        }

        public DynamicList<Boleto> getBoletos() {
                boletos = all();
                return boletos;
        }

        public void setBoletos(DynamicList<Boleto> boletos) {
                this.boletos = boletos;
        }
        
        
}
