package practica2;

public class Practica2 {

        public static void main(String[] args) {
                
        }
        
}
