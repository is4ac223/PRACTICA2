package controlador.Utiles;

import java.time.LocalDate;
import javax.swing.JTextField;

public class Utiles {
        public static Boolean validarMes(JTextField mes){
                return Integer.parseInt(mes.getText().trim())  <= 12;
        }
        
        public static Boolean valiDia(JTextField dia, JTextField mes){
                return Integer.valueOf(dia.getText().trim()) <= validarDia(mes);
        }
        
        public static Integer validarDia(JTextField mes){
                Integer auxMes = Integer.valueOf(mes.getText().trim());
                Integer auxDias;
                switch (auxMes) {
                        case 1: case 3: case 5: case 7: case 8: case 10: case 12:
                                return auxDias = 31;
                        case 4: case 6: case 9: case 11:
                                return auxDias = 30;
                        case 2:
                                return auxDias = 28;
                        default:
                                break;
                }
                return null;
        }
        
        
        
        public static LocalDate pasarFecha(JTextField dia, JTextField mes, JTextField anio){
                try {
                        int diaAux = Integer.parseInt(dia.getText().trim());
                        int mesAux = Integer.parseInt(mes.getText().trim());
                        int anioAux = Integer.parseInt(anio.getText().trim());
                        LocalDate aux = LocalDate.of(anioAux, mesAux, diaAux);
                        return aux;
                } catch (Exception e) {
                        return null;
                }
        }
        
        /*Integer diaAux = Integer.valueOf(dia.getText().trim());
                        mesAux = Integer.valueOf(mes.getText().trim());
                        int anioAux = Integer.parseInt(anio.getText().trim());
                        LocalDate aux = LocalDate.of(anioAux, mesAux, diaAux);
        return aux;*/
}
