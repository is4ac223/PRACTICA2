package vista;

import contrladorLista.DynamicList;
import controlador.CompraControl;
import controlador.Utiles.Utiles;
import emptyException.EmptyException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import modelo.Compra;
import vista.listas.tablas.ModeloTablaVenta;

public class frmPrincipal extends javax.swing.JFrame {

        private CompraControl compraControl = new CompraControl();
        private ModeloTablaVenta mtv = new ModeloTablaVenta();
        private controladorDao.persona.CompraControl control = new controladorDao.persona.CompraControl(); 

        /**
         * Creates new form frmPrincipal
         */
        public frmPrincipal() {
                initComponents();
                limpiar();
        }
        
        private void cargarTabla(){
                mtv.setCompras(control.all());
                tblVentas.setModel(mtv);
                tblVentas.updateUI();
        }
        
        public void cargarCompras(DynamicList<Compra> compras){
                mtv.setCompras(compras);
        }
        
        private void limpiar(){
                txtDni.setEnabled(true);
                tblVentas.clearSelection();
                txtApellido.setText(" ");
                txtDni.setText(" ");
                txtNombre.setText(" ");
                txtOrigen.setText(" ");
                txtDestino.setText(" ");
                txtDiaSalida.setText(" ");
                txtDiaVenta.setText(" ");
                txtMesSalida.setText(" ");
                txtMesVenta.setText(" ");
                txtAnioSalida.setText(" ");
                txtAnioVenta.setText(" ");
                txtPrecio.setText(" ");
                cargarTabla();
        }
        
        private Boolean validar(){
                return (!txtApellido.getText().trim().isEmpty() && 
                        !txtDni.getText().trim().isEmpty() && 
                        !txtNombre.getText().trim().isEmpty() && 
                        !txtOrigen.getText().trim().isEmpty() &&
                        !txtDestino.getText().trim().isEmpty() &&
                        !txtDiaSalida.getText().trim().isEmpty() &&
                        !txtDiaVenta.getText().trim().isEmpty() &&
                        !txtMesSalida.getText().trim().isEmpty() &&
                        !txtMesVenta.getText().trim().isEmpty() &&
                        !txtAnioSalida.getText().trim().isEmpty() &&       
                        !txtAnioVenta.getText().trim().isEmpty());
        }
        
        
        private void guardar() throws emptyException.EmptyException{
                if (validar()) {
                                if(Utiles.valiDia(txtDiaSalida, txtMesSalida)){
                                        if (Utiles.valiDia(txtDiaVenta, txtMesVenta)) {
                                                compraControl.getCompra().getPersona().setDni(txtDni.getText().trim());
                                                compraControl.getCompra().getPersona().setApellido(txtApellido.getText().trim());
                                                compraControl.getCompra().getPersona().setNombre(txtNombre.getText().trim());
                                                compraControl.getCompra().getBoleto().setDestino(txtDestino.getText().trim());
                                                compraControl.getCompra().getBoleto().setOrigen(txtOrigen.getText().trim());
                                                compraControl.getCompra().getBoleto().setPrecio(Double.valueOf(txtPrecio.getText().trim()));
                                                compraControl.getCompra().getBoleto().setFecha_Salida(Utiles.pasarFecha(txtDiaSalida, txtMesSalida, txtAnioSalida));
                                                compraControl.getCompra().setFecha_Venta(Utiles.pasarFecha(txtDiaVenta, txtMesVenta, txtAnioVenta));
                                                if(compraControl.guardar()){
                                                        control.persist(compraControl.getCompra());
                                                        JOptionPane.showMessageDialog(null, "Datos guardados", "Ok",
                                                        JOptionPane.INFORMATION_MESSAGE);
                                                        cargarTabla();
                                                        limpiar();
                                                        compraControl.setCompra(null);
                                                } else {
                                                JOptionPane.showMessageDialog(null, "No se pudo guardar, hubo un error", "ERROR",
                                                        JOptionPane.ERROR_MESSAGE);
                                                }
                                        } else {
                                                JOptionPane.showMessageDialog(null, "El número de dias en fecha de venta es incorrecto", "Fecha de venta",
                                JOptionPane.ERROR_MESSAGE);
                                        }
                                } else {
                                        JOptionPane.showMessageDialog(null, "El número de dias en fecha de salida es incorrecto", "Fecha de salida",
                                JOptionPane.ERROR_MESSAGE);
                                }
                        }  else {
                        JOptionPane.showMessageDialog(null, "Falta llenar campos", "Error", JOptionPane.ERROR_MESSAGE);
                }
        }
        
        private void nroBoletosVendidos(){
                Integer aux = tblVentas.getRowCount();
                txtBoletosVendidos.setEditable(false);
                txtBoletosVendidos.setText(aux.toString());
        }
        
        public void ventaTotalBoletos(){
                Double aux = 0.0;
                for (int i = 0; i < tblVentas.getRowCount(); i++) {
                        aux =  aux + Double.valueOf((tblVentas.getValueAt(i, 5)).toString());
                }
                txtCalcularVenta.setEditable(false);
                txtCalcularVenta.setText(aux.toString());
        }
        
        @SuppressWarnings("unchecked")
        // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
        private void initComponents() {

                jPanel1 = new javax.swing.JPanel();
                jLabel1 = new javax.swing.JLabel();
                jPanel2 = new javax.swing.JPanel();
                jLabel2 = new javax.swing.JLabel();
                jLabel4 = new javax.swing.JLabel();
                jLabel5 = new javax.swing.JLabel();
                jLabel6 = new javax.swing.JLabel();
                txtNombre = new javax.swing.JTextField();
                txtApellido = new javax.swing.JTextField();
                txtDni = new javax.swing.JTextField();
                jPanel3 = new javax.swing.JPanel();
                jLabel3 = new javax.swing.JLabel();
                jLabel7 = new javax.swing.JLabel();
                jLabel8 = new javax.swing.JLabel();
                jLabel9 = new javax.swing.JLabel();
                jLabel10 = new javax.swing.JLabel();
                jLabel11 = new javax.swing.JLabel();
                jLabel12 = new javax.swing.JLabel();
                jLabel13 = new javax.swing.JLabel();
                txtOrigen = new javax.swing.JTextField();
                txtDestino = new javax.swing.JTextField();
                txtDiaVenta = new javax.swing.JTextField();
                txtMesVenta = new javax.swing.JTextField();
                txtAnioVenta = new javax.swing.JTextField();
                jLabel17 = new javax.swing.JLabel();
                txtDiaSalida = new javax.swing.JTextField();
                jLabel18 = new javax.swing.JLabel();
                txtMesSalida = new javax.swing.JTextField();
                jLabel19 = new javax.swing.JLabel();
                txtAnioSalida = new javax.swing.JTextField();
                jLabel14 = new javax.swing.JLabel();
                txtPrecio = new javax.swing.JTextField();
                btnGuardar = new javax.swing.JButton();
                jScrollPane1 = new javax.swing.JScrollPane();
                tblVentas = new javax.swing.JTable();
                jLabel15 = new javax.swing.JLabel();
                jLabel16 = new javax.swing.JLabel();
                txtBoletosVendidos = new javax.swing.JTextField();
                btnBoletosVendidos = new javax.swing.JButton();
                jLabel20 = new javax.swing.JLabel();
                txtCalcularVenta = new javax.swing.JTextField();
                jLabel21 = new javax.swing.JLabel();
                btnCalcularVenta = new javax.swing.JButton();

                setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

                jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

                jLabel1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
                jLabel1.setText("VENTA DE BOLETOS");

                jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

                jLabel2.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
                jLabel2.setText("Datos Pasajero");
                jLabel2.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

                jLabel4.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
                jLabel4.setText("Nombre:");

                jLabel5.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
                jLabel5.setText("Apellido:");

                jLabel6.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
                jLabel6.setText("DNI:");

                javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
                jPanel2.setLayout(jPanel2Layout);
                jPanel2Layout.setHorizontalGroup(
                        jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(0, 0, Short.MAX_VALUE))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(txtApellido))
                                        .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(txtDni)))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                );
                jPanel2Layout.setVerticalGroup(
                        jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel4)
                                        .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel5)
                                        .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel6)
                                        .addComponent(txtDni, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addContainerGap(10, Short.MAX_VALUE))
                );

                jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

                jLabel3.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
                jLabel3.setText("Datos Boleto");

                jLabel7.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
                jLabel7.setText("Origen:");

                jLabel8.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
                jLabel8.setText("Destino:");

                jLabel9.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
                jLabel9.setText("Fecha de venta");

                jLabel10.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
                jLabel10.setText("Dia:");

                jLabel11.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
                jLabel11.setText("Mes:");

                jLabel12.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
                jLabel12.setText("Año:");

                jLabel13.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
                jLabel13.setText("Fecha de salida");

                txtOrigen.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                txtOrigenActionPerformed(evt);
                        }
                });

                txtDiaVenta.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                txtDiaVentaActionPerformed(evt);
                        }
                });

                txtMesVenta.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                txtMesVentaActionPerformed(evt);
                        }
                });

                txtAnioVenta.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                txtAnioVentaActionPerformed(evt);
                        }
                });

                jLabel17.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
                jLabel17.setText("Dia:");

                jLabel18.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
                jLabel18.setText("Mes:");

                txtMesSalida.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                txtMesSalidaActionPerformed(evt);
                        }
                });

                jLabel19.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
                jLabel19.setText("Año:");

                txtAnioSalida.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                txtAnioSalidaActionPerformed(evt);
                        }
                });

                jLabel14.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
                jLabel14.setText("Precio:");

                javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
                jPanel3.setLayout(jPanel3Layout);
                jPanel3Layout.setHorizontalGroup(
                        jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGroup(jPanel3Layout.createSequentialGroup()
                                                        .addComponent(jLabel7)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                        .addComponent(txtOrigen, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGroup(jPanel3Layout.createSequentialGroup()
                                                        .addComponent(jLabel8)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                        .addComponent(txtDestino))
                                                .addComponent(jLabel9)
                                                .addGroup(jPanel3Layout.createSequentialGroup()
                                                        .addGap(26, 26, 26)
                                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                .addGroup(jPanel3Layout.createSequentialGroup()
                                                                        .addComponent(jLabel10)
                                                                        .addGap(18, 18, 18)
                                                                        .addComponent(txtDiaVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addGap(18, 18, 18)
                                                                        .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                                .addGroup(jPanel3Layout.createSequentialGroup()
                                                                        .addComponent(jLabel11)
                                                                        .addGap(12, 12, 12)
                                                                        .addComponent(txtMesVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addGap(18, 18, 18)
                                                                        .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                        .addComponent(jLabel13)
                                        .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addGap(23, 23, 23)
                                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                .addGroup(jPanel3Layout.createSequentialGroup()
                                                                        .addComponent(jLabel17)
                                                                        .addGap(18, 18, 18)
                                                                        .addComponent(txtDiaSalida, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                                .addGroup(jPanel3Layout.createSequentialGroup()
                                                                        .addComponent(jLabel18)
                                                                        .addGap(12, 12, 12)
                                                                        .addComponent(txtMesSalida, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                                .addGroup(jPanel3Layout.createSequentialGroup()
                                                                        .addComponent(jLabel19)
                                                                        .addGap(12, 12, 12)
                                                                        .addComponent(txtAnioSalida, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                        .addGroup(jPanel3Layout.createSequentialGroup()
                                                                .addComponent(jLabel12)
                                                                .addGap(12, 12, 12)
                                                                .addComponent(txtAnioVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                );
                jPanel3Layout.setVerticalGroup(
                        jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel7)
                                        .addComponent(txtOrigen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel8)
                                        .addComponent(txtDestino, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel10)
                                        .addComponent(txtDiaVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel14))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(txtMesVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel11)
                                        .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(txtAnioVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel12))
                                .addGap(12, 12, 12)
                                .addComponent(jLabel13)
                                .addGap(18, 18, 18)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel17)
                                        .addComponent(txtDiaSalida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(txtMesSalida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel18))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(txtAnioSalida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel19))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                );

                btnGuardar.setFont(new java.awt.Font("Dialog", 3, 12)); // NOI18N
                btnGuardar.setText("Guardar");
                btnGuardar.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                btnGuardarActionPerformed(evt);
                        }
                });

                tblVentas.setModel(new javax.swing.table.DefaultTableModel(
                        new Object [][] {
                                {null, null, null, null, null, null},
                                {null, null, null, null, null, null},
                                {null, null, null, null, null, null},
                                {null, null, null, null, null, null}
                        },
                        new String [] {
                                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6"
                        }
                ));
                jScrollPane1.setViewportView(tblVentas);

                jLabel15.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
                jLabel15.setText("Nro Boletos:");

                jLabel16.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
                jLabel16.setText("VENTA DE BOLETOS");

                btnBoletosVendidos.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
                btnBoletosVendidos.setText("Número de boletos vendidos");
                btnBoletosVendidos.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                btnBoletosVendidosActionPerformed(evt);
                        }
                });

                jLabel20.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
                jLabel20.setText("Total Boletos:");

                jLabel21.setText("$");

                btnCalcularVenta.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
                btnCalcularVenta.setText("Calcular venta boletos");
                btnCalcularVenta.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                btnCalcularVentaActionPerformed(evt);
                        }
                });

                javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
                jPanel1.setLayout(jPanel1Layout);
                jPanel1Layout.setHorizontalGroup(
                        jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(26, 26, 26)
                                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addContainerGap()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                                .addGap(6, 6, 6)
                                                                .addComponent(btnGuardar)
                                                                .addGap(0, 0, Short.MAX_VALUE))
                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                                .addGap(18, 18, 18)
                                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 701, Short.MAX_VALUE)
                                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                                                                .addComponent(btnBoletosVendidos)
                                                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                                                                .addComponent(btnCalcularVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                                                                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                                                .addGap(35, 35, 35)
                                                                                                .addComponent(txtBoletosVendidos, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                                                .addGap(37, 37, 37)
                                                                                                .addComponent(jLabel20)
                                                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                                                                .addComponent(txtCalcularVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                                                                .addComponent(jLabel21)))
                                                                                .addGap(0, 0, Short.MAX_VALUE)))))))
                                .addContainerGap())
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(273, 273, 273))
                );
                jPanel1Layout.setVerticalGroup(
                        jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel16)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(10, 10, 10)
                                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 314, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(24, 24, 24)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                        .addComponent(jLabel15)
                                                        .addComponent(txtBoletosVendidos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(jLabel20)
                                                        .addComponent(txtCalcularVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(jLabel21))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                        .addComponent(btnBoletosVendidos)
                                                        .addComponent(btnCalcularVenta))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnGuardar)
                                .addContainerGap(28, Short.MAX_VALUE))
                );

                javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
                getContentPane().setLayout(layout);
                layout.setHorizontalGroup(
                        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                );
                layout.setVerticalGroup(
                        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                );

                pack();
        }// </editor-fold>//GEN-END:initComponents

        private void txtAnioVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAnioVentaActionPerformed
                // TODO add your handling code here:
        }//GEN-LAST:event_txtAnioVentaActionPerformed

        private void txtMesVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMesVentaActionPerformed
                // TODO add your handling code here:
        }//GEN-LAST:event_txtMesVentaActionPerformed

        private void txtMesSalidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMesSalidaActionPerformed
                // TODO add your handling code here:
        }//GEN-LAST:event_txtMesSalidaActionPerformed

        private void txtAnioSalidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAnioSalidaActionPerformed
                // TODO add your handling code here:
        }//GEN-LAST:event_txtAnioSalidaActionPerformed

        private void txtOrigenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtOrigenActionPerformed
                // TODO add your handling code here:
        }//GEN-LAST:event_txtOrigenActionPerformed

        private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
                try {
                        guardar();
                } catch (EmptyException ex) {
                        Logger.getLogger(frmPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                }
        }//GEN-LAST:event_btnGuardarActionPerformed

        private void txtDiaVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDiaVentaActionPerformed
                // TODO add your handling code here:
        }//GEN-LAST:event_txtDiaVentaActionPerformed

        private void btnBoletosVendidosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBoletosVendidosActionPerformed
                nroBoletosVendidos();
        }//GEN-LAST:event_btnBoletosVendidosActionPerformed

        private void btnCalcularVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCalcularVentaActionPerformed
                ventaTotalBoletos();
        }//GEN-LAST:event_btnCalcularVentaActionPerformed

        /**
         * @param args the command line arguments
         */
        public static void main(String args[]) {
                /* Set the Nimbus look and feel */
                //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
                /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
                 */
                try {
                        for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                                if ("Nimbus".equals(info.getName())) {
                                        javax.swing.UIManager.setLookAndFeel(info.getClassName());
                                        break;
                                }
                        }
                } catch (ClassNotFoundException ex) {
                        java.util.logging.Logger.getLogger(frmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                } catch (InstantiationException ex) {
                        java.util.logging.Logger.getLogger(frmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                } catch (IllegalAccessException ex) {
                        java.util.logging.Logger.getLogger(frmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                } catch (javax.swing.UnsupportedLookAndFeelException ex) {
                        java.util.logging.Logger.getLogger(frmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                }
                //</editor-fold>

                /* Create and display the form */
                java.awt.EventQueue.invokeLater(new Runnable() {
                        public void run() {
                                frmPrincipal prin = new frmPrincipal();
                                prin.setVisible(true);
                                prin.setLocationRelativeTo(null);
                        }
                });
        }

        // Variables declaration - do not modify//GEN-BEGIN:variables
        private javax.swing.JButton btnBoletosVendidos;
        private javax.swing.JButton btnCalcularVenta;
        private javax.swing.JButton btnGuardar;
        private javax.swing.JLabel jLabel1;
        private javax.swing.JLabel jLabel10;
        private javax.swing.JLabel jLabel11;
        private javax.swing.JLabel jLabel12;
        private javax.swing.JLabel jLabel13;
        private javax.swing.JLabel jLabel14;
        private javax.swing.JLabel jLabel15;
        private javax.swing.JLabel jLabel16;
        private javax.swing.JLabel jLabel17;
        private javax.swing.JLabel jLabel18;
        private javax.swing.JLabel jLabel19;
        private javax.swing.JLabel jLabel2;
        private javax.swing.JLabel jLabel20;
        private javax.swing.JLabel jLabel21;
        private javax.swing.JLabel jLabel3;
        private javax.swing.JLabel jLabel4;
        private javax.swing.JLabel jLabel5;
        private javax.swing.JLabel jLabel6;
        private javax.swing.JLabel jLabel7;
        private javax.swing.JLabel jLabel8;
        private javax.swing.JLabel jLabel9;
        private javax.swing.JPanel jPanel1;
        private javax.swing.JPanel jPanel2;
        private javax.swing.JPanel jPanel3;
        private javax.swing.JScrollPane jScrollPane1;
        private javax.swing.JTable tblVentas;
        private javax.swing.JTextField txtAnioSalida;
        private javax.swing.JTextField txtAnioVenta;
        private javax.swing.JTextField txtApellido;
        private javax.swing.JTextField txtBoletosVendidos;
        private javax.swing.JTextField txtCalcularVenta;
        private javax.swing.JTextField txtDestino;
        private javax.swing.JTextField txtDiaSalida;
        private javax.swing.JTextField txtDiaVenta;
        private javax.swing.JTextField txtDni;
        private javax.swing.JTextField txtMesSalida;
        private javax.swing.JTextField txtMesVenta;
        private javax.swing.JTextField txtNombre;
        private javax.swing.JTextField txtOrigen;
        private javax.swing.JTextField txtPrecio;
        // End of variables declaration//GEN-END:variables
}
